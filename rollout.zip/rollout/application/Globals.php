<?php

	// Set this to true to show debugging
	define("DEBUG", true);


	// You can change this to let your files
	// stays protected.
	define("KEY_SALT", 'aghtUJ6y21klnQ83Bj23B');

?>