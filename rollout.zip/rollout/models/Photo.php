<?php
 
class Photo
{
	public $photo_id;
    public $photo_url;
    public $thumb_url;
    public $restaurant_id;
    public $created_at;


    // constructor
    function __construct() 
    {

    }
 
    // destructor
    function __destruct() 
    {
         
    }
}
 
?>